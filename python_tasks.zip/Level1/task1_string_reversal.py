# Task 1: String Reversal
s = input("Enter a string: ")
print("Reversed:", s[::-1])
