# Task 4: Fibonacci Sequence
n = int(input("Enter number: "))
a, b = 0, 1

for _ in range(n):
    print(a, end=" ")
    a, b = b, a + b
