# Task 3: Task Automation
import os

files = os.listdir(".")
for f in files:
    print(f)
